function  [time,xPos,theta] = MatthewsFunction(tVInput,wVInput,PID,activeCart, functionPlots, graphCentering,cartAnnotations)
% Known Values and vector definitions
%close all, clear all, clc
%For testing
%tVInput = linspace(0,10,100); 
%wVInput = 0*sin(tVInput);

M = 0.5; %kg
m = 0.2; %kg
b = 0.1 ; %N/m/sec
l = 0.3; %m
I = 0.006; %kg.m^2
g = 9.81; %m/sec^2
r = pi; %reference 
theta0 = 3.2; %rad
t = 0; %time vector
forcing = 0; %forcing vector
errv = 0; %Error vector
errdv = 0; %Derivative vector
erriv = 0; %Integral vector
err = 0; %error
erri = 0; %integral error
errd = 0; %derivative erro
TotalTime = tVInput(end); %10 second experiment
x= [0 0 theta0 0]; %y1 y2 y3 y4 at t0 x xdot theta thetadot: initial points
options = [];
dt = 1e-2; % 10ms
N = round(TotalTime/dt); %How to make it compatible with inputted force

%% interp for function use
range = tVInput(1):dt:tVInput(end);
w = interp1(tVInput,wVInput,range);

%% Making the box and pend. initial conditions
if activeCart == 1
    figure(1);
    xR = [-.1 .1 .1 -.1 -.1];
    yR = [0 0 .1 .1 0];
    hSquare = plot(xR, yR, 'b-', 'LineWidth', 2 ); % save the handle to the square grapics object
    hold on;
    yline(0)
    xlim([-.75 .75]);
    ylim([-.75 .75]);
    xLrange = 0:0.25:2;
    xC = (xR(1)+xR(2))/2; % Specify your starting x
    yC = .1;  % Specify your starting y
    x2=xC+(.3*cos(x(end,3)-pi/2));
    y2=yC+(.3*sin(x(end,3)-pi/2));
    Pendulum = plot([xC x2],[yC y2], 'LineWidth', 7);
    xlabel('meters');
    Pendulum.Marker = '.';
    Pendulum.MarkerSize = 24;
    set(gca, 'YTick', []);  % set the y-axis tick marks to empty

    positionMarker = plot([0 0],[0 -.75], '--' ,'LineWidth', 1);
    a1=[];
end

%% Making the PID
ku = 87; %found via trial and error
%PID = 1; % 1 for on 0 for off
kp = 140* PID; %%136 * PID;
ki = 850* PID; %814.37 * PID;
kd = 8.5* PID; % 5.678 * PID;

%% Running the simulation
for k = 1:N
    t1 = t(end);
    t2 = t1+dt;
    u = kp*err + ki*erri+kd*errd;
    F=u+w(k); %Takes the force at a specific point
    forcing = [forcing;u];
    [tout,out] = ode45(@secondorderfunTheta,[t1 t2],x(end,:),options,M,m,b,l,I,g,F);
    t = [t;tout(end)];
    x = [x;out(end,:)];
    err = r - x(end,3);
    %err = round(err, 3);
    errd = (err - errv(end))/dt;
    %errd = round(errd, 3);
    erri = erriv(end)+(err+errv(end))/2*dt;
    %erri = round(erri, 3);
    errv = [errv;err];
    errdv = [errdv;errd];
    erriv = [erriv;erri];
    
    % This updates the pendulum
    if activeCart == 1
        xRc = [xR(1)+x(end,1) xR(2)+x(end,1) xR(3)+x(end,1) xR(4)+x(end,1), xR(5)+x(end,1)]; %Defines the corners of the rectanle
        set(hSquare, 'XData', xRc); %Updates the hSquare plot with new corners
        xC = (xRc(1)+xRc(2))/2; % Defines the start of the pendulum by using the average of box corners
        yC = .1;  % Specify your starting y, just the top of the box
        x2=xC+(.3*cos(x(end,3)-pi/2)); %Uses trig to find x cord.
        y2=yC+(.3*sin(x(end,3)-pi/2)); %uses trig to find y cord.
        set(Pendulum, 'XData', [xC x2], 'YData', [yC y2]); %updates the pendulum line with new points
        set(positionMarker,'XData', [xC xC]);
        if graphCentering == 0
            xlim([-.75+(xC) .75+(xC)]); %adjusts the plot view to keep cart centered
        end
        if cartAnnotations == 1
            %Stuff for on screen annotations, but causes lag tho
            dim = [0.15 0.6 0.3 0.3];
            str = {"Time = "+ sprintf('%.2f',t1) + " sec", "X pos = "+ sprintf('%.2f',xC) + " meters", "Theta = "+ sprintf('%.2f',x(end,3))+ " rad"};
            delete(a1);
            a1 = annotation('textbox',dim,'string',str,'FitBoxToText','on');
        end
        %cla;
        %pause(0.001);
        drawnow limitrate; %limits the frame rate. this gave me the best fps
    end
end

%% Displaying the data
if functionPlots == 1
    figure;
    tiledlayout(1,5)
    nexttile
    plot(t,x(:,1))
    title('X vs time');
    xlabel('Time t');
    ylabel('Pos in meters');
    nexttile
    plot(t,x(:,3))
    title('Theta vs time');
    xlabel('Time t');
    ylabel('Theta in rad');
    nexttile
    plot(t,forcing)
    title('PID vs time');
    xlabel('Time t');
    ylabel('Force in N');
    nexttile
    plot(t,w)
    title('w vs time');
    xlabel('Time t');
    ylabel('Force in N');
    nexttile
    plot(t,errv)
    title('Error vs time');
    xlabel('Time t');
    ylabel('Error in rads');
end

time = t;
xPos = x(:,1);
theta = x(:,3);


%% For tuning PID but no longer useful
 %[idx,idx]=findpeaks(theta);
 %Pu=t(idx(2))-t(idx(1)); % The ultimate period (sec) 0.3300
 %kp=1.6*ku;
 %ki=3.2*ku/Pu;
 %kd=.2*Pu*ku;

