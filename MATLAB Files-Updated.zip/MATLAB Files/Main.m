clear all; close all; clc;
t = linspace(0,10,200);%Time vector, function uses the final time to figure out how long to simulate for
w = zeros(1,length(t));
for i = 1: length(t)
    if t(i) >= 1 && t(i) <= 1.1
        w(i) = 10; %forcing vector. This needs to have the same number of elements as the time vector
    end
end

PID = 1; %1 for on, 0 for off
cart = 1;%Will activly show cart (makes the sim. slow) 1 for on, 0 for off
cartAnnotations = 1;%shows annotations(also slow)
functionPlots = 1; %Will show plots after sim is done 1 for on, 0 for off
graphCentering = 0; %1 will keep 0 in the center(Might go off screen), 0 will make the cart be centered in the graph
[time,x,theta] = MatthewsFunction(t,w, PID, cart, functionPlots, graphCentering,cartAnnotations);
%%
figure;
tiledlayout(1,2)
nexttile
plot(time,x)
title('X vs time');
xlabel('Time t');
ylabel('Pos in meters');
nexttile
plot(time,theta)
title('Theta vs time');
xlabel('Time t');
ylabel('Theta in rad');
