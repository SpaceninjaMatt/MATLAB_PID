function thetadot = secondorderfunTheta(t, y, M, m, b, l, I, g, F)
%y vector is [y1 y2 y3 y4]
ydot1 = y(2);
ydot2 = (F-b*y(2)+m*l*(y(4)^2)*sin(y(3))+((m*l)^2*g*sin(y(3))*cos(y(3)))/(1+m*l^2))/((M+m)-((m*l)^2*cos(y(3))^2)/(I+m*l^2));
ydot3 = y(4);
ydot4 = (F+(M+m)*g*tan(y(3))-b*y(2)+m*l*y(4)^2*sin(y(3)))/(((M+m)*(I+m*l^2))/(-m*l*cos(y(3)))+m*l*cos(y(3)));
thetadot = [ydot1 ydot2 ydot3 ydot4]';
end 